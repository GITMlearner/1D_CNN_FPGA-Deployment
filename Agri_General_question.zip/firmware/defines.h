#ifndef DEFINES_H_
#define DEFINES_H_

#include "ap_fixed.h"
#include "ap_int.h"
#include "nnet_utils/nnet_types.h"
#include <array>
#include <cstddef>
#include <cstdio>
#include <tuple>
#include <tuple>


// hls-fpga-machine-learning insert numbers

// hls-fpga-machine-learning insert layer-precision
typedef ap_fixed<16,6> input_t;
typedef ap_fixed<16,6> model_default_t;
typedef ap_fixed<35,15> conv1d_2_result_t;
typedef ap_fixed<16,6> conv1d_2_weight_t;
typedef ap_fixed<16,6> conv1d_2_bias_t;
typedef ap_fixed<16,6> layer3_t;
typedef ap_fixed<18,8> conv1d_2_relu_table_t;
typedef ap_fixed<16,6> layer4_t;
typedef ap_fixed<40,20> conv1d_3_result_t;
typedef ap_fixed<16,6> conv1d_3_weight_t;
typedef ap_fixed<16,6> conv1d_3_bias_t;
typedef ap_fixed<16,6> layer6_t;
typedef ap_fixed<18,8> conv1d_3_relu_table_t;
typedef ap_fixed<16,6> layer7_t;
typedef ap_fixed<39,19> dense_2_result_t;
typedef ap_fixed<16,6> dense_2_weight_t;
typedef ap_fixed<16,6> dense_2_bias_t;
typedef ap_uint<1> layer8_index;
typedef ap_fixed<16,6> layer9_t;
typedef ap_fixed<18,8> dense_2_relu_table_t;
typedef ap_fixed<38,18> dense_3_result_t;
typedef ap_fixed<16,6> dense_3_weight_t;
typedef ap_fixed<16,6> dense_3_bias_t;
typedef ap_uint<1> layer11_index;
typedef ap_fixed<16,6> result_t;
typedef ap_fixed<18,8> dense_3_softmax_table_t;
typedef ap_fixed<18,8,AP_RND,AP_SAT,0> dense_3_softmax_exp_table_t;
typedef ap_fixed<18,8,AP_RND,AP_SAT,0> dense_3_softmax_inv_table_t;
typedef ap_fixed<18,8,AP_RND,AP_SAT,0> dense_3_softmax_inv_inp_t;

// hls-fpga-machine-learning insert emulator-defines


#endif
